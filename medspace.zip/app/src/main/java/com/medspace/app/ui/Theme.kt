package com.medspace.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0E7C86),
    background = Color(0xFFF6FAFA),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF10262B),
    onSurfaceVariant = Color(0xFF5A6F73)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4FD1DC),
    background = Color(0xFF0B171A),
    surface = Color(0xFF122428),
    onBackground = Color(0xFFE6F2F3),
    onSurfaceVariant = Color(0xFF9DB4B8)
)

@Composable
fun MedspaceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
